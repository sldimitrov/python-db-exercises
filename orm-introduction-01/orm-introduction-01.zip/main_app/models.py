from django.db import models

# Create your models here.
class Employee(models.Model):
    name = models.CharField(max_length=30)
    email_address = models.EmailField()
    photo = models.URLField()
    birth_date = models.DateField()
    work_full_time = models.BooleanField()
    created_now = models.DateTimeField(auto_now_add=True)

class Department(models.Model):
    class Cities(models.TextChoices):
        SF = 'S', 'Sofia'
        PD = 'P', 'Plovdiv'
        V = 'V', 'Varna'
        BS = 'Bs', 'Burgas'

    code = models.CharField(max_length=4, primary_key=True, unique=True)
    name = models.CharField(max_length=50, unique=True)
    employees_count = models.PositiveIntegerField(default=1, verbose_name='Employees Count')
    location = models.CharField(
        max_length=20,
        choices=Cities.choices,
        null=True,
        blank=True
    )
    last_edited_on = models.DateTimeField(auto_now_add=True, editable=False)

